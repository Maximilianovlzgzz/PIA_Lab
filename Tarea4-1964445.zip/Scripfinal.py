#Importamos Modulos 
from cgitb import text
from itertools import zip_longest
from turtle import title
import requests
from bs4 import BeautifulSoup
import csv
# Obtencion de datos mediante la peticion GET
URL = "https://realpython.github.io/fake-jobs/"
page = requests.get(URL)
# Analizamos el contenido HTML con BeautifulSoup
soup = BeautifulSoup(page.content, "html.parser")
results = soup.find(id="ResultsContainer")
# Buscamos todos los elementos  que el class "card-content"
job_elements = results.find_all("div", class_="card-content")
#Buscar todos los elementos que el h2 contenga en su texto 
# la palabra "python"
python_jobs = results.find_all(
    "h2", string=lambda text: "python" in   text.lower()
    )
#Buscar cada elemento que contenga referencias a python
#Y almacenarlo en python_jobs_elements
python_jobs_elements = [
    h2_element.parent.parent.parent for h2_element in python_jobs
    ]
#Creamos el archivo.csv para guardar los datos
with open('./tryouts.csv', 'w',newline='') as csv_file:
#Mostramos la informacion de python_jobs_elements
    for job_element in python_jobs_elements:
        title_element = job_element.find("h2", class_="title")
        company_element = job_element.find("h3", class_="company")
        location_element = job_element.find("p", class_="location")
#Buscamos elemetnos con la etiqueta "a"
#Imprimimos los elementos
        link_url = job_element.find_all("a")[1]["href"]
        print(title_element.text.strip())
        print(location_element.text.strip())
        print(company_element.text.strip())
        print(f"Apply Here: {link_url}\n")
        print()
        list=[(title_element.text.strip()),(location_element.text.strip()),(company_element.text.strip()), (f"Apply Here: {link_url}\n"),""]
        print (list)
        csv_writer = csv.writer(csv_file, dialect='excel')
        csv_writer.writerows(zip(list))