#!/bin/bash
#
# Ejemplo de Menu en BASH
#
date
    echo "---------------------------"
    echo "   Menu Principal"
    echo "---------------------------"
    echo "1. Net Discover"
    echo "2. Post scanner"
    echo "3. Information"
    echo "4. Exit"
read -p "Opción  [ 1 - 4 ] " c
case $c in
        1) ./Netdiscover1.sh;;
        2) ./portscanv1.sh;;
        3) ./bienvenida.sh;;
        4) echo "Bye!"; exit 0;;
esac
