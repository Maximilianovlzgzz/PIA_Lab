#!/bin/bash
echo "Hostname: {$HOSTNAME}"
echo "Username: {$LOGNAME}"
echo "Fecha: $(date)"
echo "Sistema operativo: " | cat /etc/os-release | grep PRETTY_NAME

