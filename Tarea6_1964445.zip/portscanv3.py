#Parte1
#Importamos librerias necesarias
import sys
import threading
from socket import *
import nmap
#Parte2
#Creamos una funcion tcp_test la cual
#Permite probar mediante socket los puertos
#abiertos, se le agrega lock.release( )
def tcp_test(port):
    sock = socket(AF_INET, SOCK_STREAM)
    ep = nmap.PortScanner()
    sock.settimeout(10)
    result = ep.scan((target_ip, port))
    if result == 0:
        print ("Opended Port:", port)
#Parte3
#Establecemos el main del script
#Guardamos en variables host y portstrs
if __name___=='__main__':
    # portscan.py <host> <start_port>-<end_port>
    host = sys.argv[1]
    portstrs = sys.arg[2].split('-')
    #Parte4
    #Portstrs se convierte en lista al momento
    #de hacer  slpit y de ahi obtener dos valores
    start_port = int(portstrs[0])
    end_port = int(portstrs[1])
    #Parte5
    #Usando al funcion gethostbyname se obtiene
    #la direccion ip.
    target_ip = gethostbyname(host)
    #Parte6
    #Se inicia bucle para probasr puertos
    #usando la funcion tcp_test y generando
    #un hilo por cada puerto a probar
    hilos = []
    for port in range(start_port, end_port):
        hilo = threading.Thread(target=tcp_test, args=(port,))
        hilos.append(hilo)
        hilo.start()