﻿#Scrip hecho por Maximiliano Velazquez Gonzalez Matricula:1964445
Write-host Menú
Write-host ====
Write-host "1) Escaneo de la red."
Write-host "2) Escaneo de puertos para un equipo o dirección ip en particular."
Write-host "3) Escaneo de puertos para todos los equipos que estén activos en la red."
$opcion = Read-Host
switch($opcion)
{
	1 { 
# Determinando gateway
$subred = (Get-NetRoute -DestinationPrefix 0.0.0.0/0 -Ifindex 5).NextHop
Write-Host "==Determinando tu gateway..."
Write-Host "Tu gateway es: $subred"
#
# Determinando rango de subred 
#
$rango = $subred.Substring(0,$subred.IndexOf('.') + 1 + $subred.Substring($subred.IndexOf('.') + 1).IndexOf('.') + 3)
Write-Host "== Determinando tu rango de subred..."
echo $rango
#
##Determinando si $rango termina en "."
##En ocasiones el rango de subred no termina en punto, necesitamos forzarlo
#
$punto = $rango.EndsWith('.')
if ( $punto -like  "False" )
{
    $rango = $rango + '.' #Con esto agregamos el punto en caso de que no estuviera
}
#
##Creamos un array con 254 numeros (1 a 254) y se almacenan
## en una variable que se llama $rango_ip
#
$rango_ip = @(1 .. 254)
#
##generamos bucle foreach para validar hosts activos en nuestra subred
#
Write-Output ""
Write-Host "== Subred actual:"
Write-Host "Escanenado: " -NoNewline ; Write-Host $rango -NoNewline; Write-Host "0/24" -ForegroundColor Red
Write-Output ""
foreach ($r in $rango_ip)
{
    $actual = $rango + $r # se geenra dicecchion ip 
    $responde = Test-Connection $actual -Quiet -Count 1 
    if ( $responde -eq "True" )
    {
        Write-Output " "
        Write-Host "Host responde: " -NoNewline; Write-Host $actual -ForegroundColor Green
    }
}
#Fin del script
;break}
	2 {
#
#Escaneo de puertos en equipos de
#misma subred
#
# Determinando gateway
$subred = (Get-NetRoute -DestinationPrefix 0.0.0.0/0 -Ifindex 5).NextHop
Write-Host "==Determinando tu gateway..."
Write-Host "Tu gateway es: $subred"
#
# Determinando rango de subred 
#
$rango = $subred.Substring(0,$subred.IndexOf('.') + 1 + $subred.Substring($subred.IndexOf('.') + 1).IndexOf('.') + 3)
Write-Host "== Determinando tu rango de subred..."
echo $rango
#
##Determinando si $rango termina en "."
##En ocasiones el rango de subred no termina en punto, necesitamos forzarlo
#
$punto = $rango.EndsWith('.')
if ( $punto -like  "False" )
{
    $rango = $rango + '.' #Con esto agregamos el punto en caso de que no estuviera
}
#
##Definimos un array con puertos a escanear.
## Establecemos una variable para Waitime 
#
$portstoscan = @(0..65535)
$waittime = 1
#
##Solicitamos direccion ip a escanear:
#
Write-Host "Direccion ip a escanear: " -NoNewline
$direccion = Read-Host
#
##Generamos un bucle foreach para evaluar  cada puerto  en $portstoscan
#
Write-Host "Escaneando puertos favor de tener paciencia..."
foreach ($p in $portstoscan)
{
    $TCPObject = new-object System.Net.Sockets.TcpClient
    try{ $resultado = $TCPObject.ConnectAsync($direccion,$p).Wait($waittime)}catch{}
    if ( $resultado -eq "True" )
    {
       Write-Host "Puerto abierto:" -NoNewline; Write-Host $p -ForegroundColor Green
    }
}
;break}
	3 {
#Escane de equipos activos en la subred
#
# Determinando gateway
$subred = (Get-NetRoute -DestinationPrefix 0.0.0.0/0 -Ifindex 5).NextHop
Write-Host "==Determinando tu gateway..."
Write-Host "Tu gateway es: $subred"
#
# Determinando rango de subred 
#
$rango = $subred.Substring(0,$subred.IndexOf('.') + 1 + $subred.Substring($subred.IndexOf('.') + 1).IndexOf('.') + 3)
Write-Host "== Determinando tu rango de subred..."
echo $rango
#
##Determinando si $rango termina en "."
##En ocasiones el rango de subred no termina en punto, necesitamos forzarlo
#
$punto = $rango.EndsWith('.')
if ( $punto -like  "False" )
{ 
    $rango = $rango + '.'  #Con esto agregamos el punto en caso de que no estuviera
}
#
##Definimos un array con puertos a escanear.
## Establecemos una variable para Waitime 
#
$portstoscan = @(0..65535)
$waittime = 10
#
##Creamos un array con 254 numeros (1 a 254) y se almacenan
## en una variable que se llama $rango_ip
#
$rango_ip = @(1 .. 254)
Write-Output ""
Write-Host "== Subred actual:"
Write-Host "Escanenado: " -NoNewline ; Write-Host $rango -NoNewline; Write-Host "0/24" -ForegroundColor Red
Write-Output ""
#
##generamos bucle foreach para validar hosts activos en nuestra subred
#
foreach ($r in $rango_ip)
{
    $actual = $rango + $r # se geenra dicecchion ip 
    $responde = Test-Connection $actual -Quiet -Count 1 
    if ( $responde -eq "True" )
    {
        Write-Output " "
        Write-Host "Host responde: " -NoNewline; Write-Host $actual -ForegroundColor Green
#
##Generamos un bucle foreach para evaluar  cada puerto  en $portstoscan
#
    foreach ($p in $portstoscan)
{
    $TCPObject = new-object System.Net.Sockets.TcpClient
    try{ $resultado = $TCPObject.ConnectAsync($actual,$p).Wait($waittime)}catch{}
    if ( $resultado -eq "True" )
    {
       Write-Host "Puerto abierto:" -NoNewline; Write-Host $p -ForegroundColor Green
    }
}
    }
}

}
	default {break}
}